<?php

namespace app\models;

use Yii;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "appointment".
 *
 * @property int $id
 * @property string $phone
 * @property int $address_id
 * @property string $time
 * @property int $master_id
 *
 * @property Address $address
 * @property Master $master
 */
class Appointment extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'appointment';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['phone', 'address_id', 'time', 'master_id'], 'required'],
            [['address_id', 'master_id'], 'integer'],
            [['time'], 'safe'],
            [['phone'], 'string', 'max' => 20],
            [['address_id'], 'exist', 'skipOnError' => true, 'targetClass' => Address::className(), 'targetAttribute' => ['address_id' => 'id']],
            [['master_id'], 'exist', 'skipOnError' => true, 'targetClass' => Master::className(), 'targetAttribute' => ['master_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'phone' => 'Phone',
            'address_id' => 'Address',
            'time' => 'Time',
            'master_id' => 'Master',
        ];
    }

    /**
     * Gets query for [[Address]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAddress()
    {
        return $this->hasOne(Address::className(), ['id' => 'address_id']);
    }

    /**
     * Gets query for [[Master]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMaster()
    {
        return $this->hasOne(Master::className(), ['id' => 'master_id']);
    }

    /**
     * Возвращает список доступных мастеров в формате [id => name] для выпадающего списка.
     *
     * @return array
     */
    public static function getMastersList()
    {
        return ArrayHelper::map(Master::find()->asArray()->all(), 'id', 'name');
    }

    /**
     * Возвращает список доступных адресов.
     *
     * @return string[]
     */
    public static function getAddressesList()
    {
        return [
            'ул. Ленина, 10',
            'пр. Мира, 25',
        ];
    }
}