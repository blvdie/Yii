<?php
namespace app\models;
use Yii;
/**
* This is the model class for table "application".
*
* @property int $id
* @property string $customer_name
* @property string $phone
* @property string|null $email
* @property string $product_name
* @property int $quantity
* @property int|null $status
* @property string|null $created_at
* @property string|null $updated_at
*/
class Application extends \yii\db\ActiveRecord
{
 const STATUS_NEW = 1;
 const STATUS_PROCESSING = 2;
 const STATUS_COMPLETED = 3;
 
 /**
 * {@inheritdoc}
 */
 public static function tableName()
 {
 return 'application';
 }
 /**
 * {@inheritdoc}
 */
 public function rules()
 {
 return [
 [['customer_name', 'phone', 'product_name', 'quantity'], 'required'],
 [['quantity', 'status'], 'integer'],
 [['created_at', 'updated_at'], 'safe'],
 [['customer_name', 'product_name'], 'string', 'max' => 255],
 [['phone'], 'string', 'max' => 20],
 [['email'], 'string', 'max' => 255],
 [['email'], 'email'],
 ['quantity', 'compare', 'compareValue' => 0, 'operator' => '>'],
 ];
 }
 /**
 * {@inheritdoc}
 */
 public function attributeLabels()
 {
 return [
 'id' => 'ID',
 'customer_name' => 'Имя клиента',
 'phone' => 'Телефон',
 'email' => 'Email',
 'product_name' => 'Название товара',
 'quantity' => 'Количество',
 'status' => 'Статус',
'created_at' => 'Дата создания',
 'updated_at' => 'Дата обновления',
 ];
 }
 
 /**
 * Перед сохранением устанавливаем даты
 */
 public function beforeSave($insert)
 {
 if (parent::beforeSave($insert)) {
 if ($this->isNewRecord) {
 $this->created_at = date('Y-m-d H:i:s');
 $this->status = self::STATUS_NEW;
 }
 $this->updated_at = date('Y-m-d H:i:s');
 return true;
 }
 return false;
 }
 
 /**
 * Получить список статусов
 */
 public static function getStatuses()
 {
 return [
 self::STATUS_NEW => 'Новая',
 self::STATUS_PROCESSING => 'В обработке',
 self::STATUS_COMPLETED => 'Выполнена',
 ];
 }
 
 /**
 * Получить название статуса
 */
 public function getStatusName()
 {
 $statuses = self::getStatuses();
 return isset($statuses[$this->status]) ? $statuses[$this->status] : 'Неизвестн
о';
 }
}
