<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
/* @var $this yii\web\View */
/* @var $model app\models\Application */
/* @var $form yii\widgets\ActiveForm */
?>
<div class="application-form">
 <?php $form = ActiveForm::begin(); ?>
 <?= $form->field($model, 'customer_name')->textInput(['maxlength' => true]) ?>
 <?= $form->field($model, 'phone')->textInput(['maxlength' => true]) ?>
 <?= $form->field($model, 'email')->textInput(['maxlength' => true]) ?>
 <?= $form->field($model, 'product_name')->textInput(['maxlength' => true]) ?>
 <?= $form->field($model, 'quantity')->textInput() ?>
 <div class="form-group">
 <?= Html::submitButton('Сохранить', ['class' => 'btn btn-success']) ?>
 </div>
 <?php ActiveForm::end(); ?>
</div>