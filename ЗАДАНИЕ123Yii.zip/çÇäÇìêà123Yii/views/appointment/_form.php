<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\widgets\MaskedInput;
use kartik\datetime\DateTimePicker;
use app\models\Appointment;

/* @var $this yii\web\View */
/* @var $model app\models\Appointment */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="appointment-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'phone')->textInput(['maxlength' => true])->widget(\yii\widgets\MaskedInput::class, [
    'mask' => '+7(999)-999-99-99',
]) ?>

    <?php
    $addresses = Appointment::getAddressesList();
    $addressList = array_combine(array_keys($addresses), $addresses);
    ?>
    <?= $form->field($model, 'address_id')->dropDownList(
        $addressList,
        ['prompt' => 'Выберите адрес']
    ) ?>

    <?= $form->field($model, 'time')->Input('datetime-local') ?>

    <?= $form->field($model, 'master_id')->dropDownList(
        Appointment::getMastersList(),
        ['prompt' => 'Выберите мастера']
    ) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>