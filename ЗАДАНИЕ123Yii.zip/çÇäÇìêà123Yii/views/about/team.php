<?php
$this->title = 'Наша команда';
?>
<?php $this->beginContent('@app/views/layouts/main.php'); ?>
<div class="team-page">
 <h1>Наша команда</h1>
 
 <div class="team-members">
 <?php foreach ($teamMembers as $member): ?>
 <div class="member-card">
 <h3><?= htmlspecialchars($member['name']) ?></h3>
 <p class="position"><?= htmlspecialchars($member['position']) ?></p>
 </div>
 <?php endforeach; ?>
 </div>
 
 <div class="navigation">
 <a href="<?= \yii\helpers\Url::to(['about/index']) ?>" class="btn btn-default">
 Назад к информации о компании
 </a>
 </div>
</div>
<style>
.team-members {
 display: flex;
 flex-wrap: wrap;
 gap: 20px;
 margin: 20px 0;
}
.member-card {
 border: 1px solid #ddd;
 padding: 15px;
 border-radius: 5px;
 width: 200px;
}
.member-card h3 {
 margin-top: 0;
 color: #333;
}
.position {
 color: #666;
 font-style: italic;
}
</style>
<?php $this->endContent(); ?>
