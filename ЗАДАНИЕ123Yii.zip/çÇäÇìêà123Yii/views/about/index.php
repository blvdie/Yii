<?php
// Устанавливаем заголовок страницы
$this->title = 'О нашей компании';
?>
<!-- Подключаем общий макет -->
<?php $this->beginContent('@app/views/layouts/main.php'); ?>
<div class="about-page">
 <h1>О компании <?= htmlspecialchars($companyName) ?></h1>
 
 <div class="company-info">
 <p><strong>Название:</strong> <?= htmlspecialchars($companyName) ?></p>
 <p><strong>Год основания:</strong> <?= $foundationYear ?></p>
 <p><strong>На рынке:</strong> <?= $currentYear - $foundationYear ?> лет</p>
 </div>
 
 <div class="company-description">
 <h2>Наша миссия</h2>
 <p>Мы стремимся предоставлять лучшие решения для наших клиентов, 
 используя современные технологии и инновационные подходы.</p>
 </div>
 
 <div class="navigation">
 <a href="<?= \yii\helpers\Url::to(['about/team']) ?>" class="btn btn-primary">
 Наша команда
 </a>
 </div>
</div>
<?php $this->endContent(); ?>