<?php
namespace app\controllers;
use yii\web\Controller;
class AboutController extends Controller
{
 /**
 * Действие по умолчанию - "index"
 * Это метод, который будет вызван при обращении к /about
 */
 public function actionIndex()
 {
 // Передаем данные в представление
 $companyName = "Наша Компания";
 $foundationYear = 2010;
 // Рендерим представление 'index' и передаем данные
 return $this->render('index', [
 'companyName' => $companyName,
 'foundationYear' => $foundationYear,
 'currentYear' => date('Y')
 ]);
 }
 
 /**
 * Дополнительное действие - "team"
 * Будет доступно по адресу /about/team
 */
 public function actionTeam()
 {
 $teamMembers = [
 ['name' => 'Иван Иванов', 'position' => 'Директор'],
 ['name' => 'Петр Петров', 'position' => 'Разработчик'],
 ['name' => 'Мария Сидорова', 'position' => 'Дизайнер']
 ];
 
 return $this->render('team', [
 'teamMembers' => $teamMembers
 ]);
 }
}
